package kurly;

public class UserDTO {
	private String user_id;
	private String user_pw;
    private String user_irum;
    private String user_email;
    private String user_hp;
    private String user_addr;
    private String user_gender;
    private String user_birth;
    private String user_chooga;
    private String user_service;
    private String user_gaib_date;
    
    
	
    public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_pw() {
		return user_pw;
	}
	public void setUser_pw(String user_pw) {
		this.user_pw = user_pw;
	}
	public String getUser_irum() {
		return user_irum;
	}
	public void setUser_irum(String user_irum) {
		this.user_irum = user_irum;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_hp() {
		return user_hp;
	}
	public void setUser_hp(String user_hp) {
		this.user_hp = user_hp;
	}
	public String getUser_addr() {
		return user_addr;
	}
	public void setUser_addr(String user_addr) {
		this.user_addr = user_addr;
	}
	public String getUser_gender() {
		return user_gender;
	}
	public void setUser_gender(String user_gender) {
		this.user_gender = user_gender;
	}
	public String getUser_birth() {
		return user_birth;
	}
	public void setUser_birth(String user_birth) {
		this.user_birth = user_birth;
	}
	public String getUser_chooga() {
		return user_chooga;
	}
	public void setUser_chooga(String user_chooga) {
		this.user_chooga = user_chooga;
	}
	public String getUser_service() {
		return user_service;
	}
	public void setUser_service(String user_service) {
		this.user_service = user_service;
	}
	public String getUser_gaib_date() {
		return user_gaib_date;
	}
	public void setUser_gaib_date(String user_gaib_date) {
		this.user_gaib_date = user_gaib_date;
	}

}
