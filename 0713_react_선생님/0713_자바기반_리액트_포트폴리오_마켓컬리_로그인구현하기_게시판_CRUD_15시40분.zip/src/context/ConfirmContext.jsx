// ConfirmContext.jsx
import {createContext} from 'react';
export const ConfirmContext = createContext(null);
